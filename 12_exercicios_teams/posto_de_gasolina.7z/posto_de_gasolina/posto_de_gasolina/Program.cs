﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace posto_de_gasolina
{
    internal class Program
    {
        static void Main(string[] args)
        //Em um posto de gasolina 10 clientes estão em uma fila para chegar em uma bomba de abastecimento, nessa bomba o
        //pagamento tem que ser feito em dinheiro ou pix, se caso o pagamento for feita em cartão o cliente tem que mudar para a bomba de abastecimento do lado.
        {
            int i = 1;
            String formaDePagamento;

            for (i = 0; i >= 0 && i <= 10; i++)
            {
                Console.WriteLine("Olá, Bem vindo ao posto Pica-Pau-Amarelo, Por favor Digite o número  da forma de pagamento");

                Console.WriteLine("Formas de pagamento: \n 1 - Dinheiro \n 2 - Pix \n 3 - Cartão");
                formaDePagamento = Console.ReadLine(); 
                
                if(formaDePagamento == "3")
                {
                    Console.WriteLine("Devido ao método de pagamento ser cartão, Você pode de locomover até a bomba ao lado,Obrigado");
                }
                else
                {
                    Console.WriteLine("Ok, começarei a abastecer seu veículo.");
                }
                Thread.Sleep(1000);
                Console.Clear();
            }
        }
    }
}
